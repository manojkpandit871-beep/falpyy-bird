package android.support.v4.view.a;

import android.os.Bundle;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
interface t {
    Object a(int i);

    List a(String str, int i);

    boolean a(int i, int i2, Bundle bundle);
}
