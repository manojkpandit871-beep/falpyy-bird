package android.support.v4.view;

import android.view.View;

/* JADX INFO: loaded from: classes.dex */
public interface cd {
    void a(View view, float f);
}
