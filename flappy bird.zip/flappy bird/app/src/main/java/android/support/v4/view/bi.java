package android.support.v4.view;

import android.graphics.Paint;
import android.view.View;

/* JADX INFO: loaded from: classes.dex */
class bi {
    public static int a(View view) {
        return view.getLayoutDirection();
    }

    public static void a(View view, Paint paint) {
        view.setLayerPaint(paint);
    }
}
