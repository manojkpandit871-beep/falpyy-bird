package android.support.v4.view;

import android.view.MotionEvent;

/* JADX INFO: loaded from: classes.dex */
interface ac {
    int a(MotionEvent motionEvent);

    int a(MotionEvent motionEvent, int i);

    int b(MotionEvent motionEvent, int i);

    float c(MotionEvent motionEvent, int i);

    float d(MotionEvent motionEvent, int i);
}
