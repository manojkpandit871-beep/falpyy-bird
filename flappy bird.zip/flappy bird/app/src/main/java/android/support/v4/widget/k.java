package android.support.v4.widget;

import android.content.Context;
import android.graphics.Canvas;

/* JADX INFO: loaded from: classes.dex */
interface k {
    Object a(Context context);

    void a(Object obj, int i, int i2);

    boolean a(Object obj);

    boolean a(Object obj, float f);

    boolean a(Object obj, Canvas canvas);

    void b(Object obj);

    boolean c(Object obj);
}
