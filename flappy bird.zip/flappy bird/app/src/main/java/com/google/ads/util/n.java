package com.google.ads.util;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.Intent;
import android.util.DisplayMetrics;

/* JADX INFO: loaded from: classes.dex */
@TargetApi(com.google.android.gms.e.MapAttrs_cameraTilt)
public final class n {
    private static int a(Context context, float f, int i) {
        return (context.getApplicationInfo().flags & 8192) != 0 ? (int) (i / f) : i;
    }

    public static int a(Context context, DisplayMetrics displayMetrics) {
        return a(context, displayMetrics.density, displayMetrics.heightPixels);
    }

    public static void a(Intent intent, String str) {
        intent.setPackage(str);
    }

    public static int b(Context context, DisplayMetrics displayMetrics) {
        return a(context, displayMetrics.density, displayMetrics.widthPixels);
    }
}
