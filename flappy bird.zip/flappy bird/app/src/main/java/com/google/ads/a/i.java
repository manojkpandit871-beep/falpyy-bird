package com.google.ads.a;

import com.google.ads.bv;
import com.google.ads.bw;
import com.google.ads.bx;
import com.google.ads.by;
import com.google.ads.bz;
import com.google.ads.ca;
import com.google.ads.ce;
import com.google.ads.cf;
import java.util.HashMap;

/* JADX INFO: loaded from: classes.dex */
final class i extends HashMap {
    i() {
        put("/open", new cf());
        put("/canOpenURLs", new bw());
        put("/close", new by());
        put("/customClose", new bz());
        put("/appEvent", new bv());
        put("/log", new ce());
        put("/click", new bx());
        put("/httpTrack", new ca());
        put("/touch", new com.google.ads.m());
        put("/video", new com.google.ads.n());
    }
}
